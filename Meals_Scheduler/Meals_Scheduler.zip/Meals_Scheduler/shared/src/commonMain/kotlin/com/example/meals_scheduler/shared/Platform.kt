package com.example.meals_scheduler.shared

expect class Platform() {
    val platform: String

}