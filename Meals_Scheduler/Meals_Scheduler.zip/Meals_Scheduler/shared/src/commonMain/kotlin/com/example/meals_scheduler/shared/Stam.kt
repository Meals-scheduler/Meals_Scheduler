package com.example.meals_scheduler.shared

class Stam {


    fun Hello(): String{
        return "Hello,Sivan!"
    }
}