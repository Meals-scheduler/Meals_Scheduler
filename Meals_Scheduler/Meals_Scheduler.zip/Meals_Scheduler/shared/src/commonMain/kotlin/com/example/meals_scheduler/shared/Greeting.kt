package com.example.meals_scheduler.shared


class Greeting {
    fun greeting(): String {
        return "Hello, elad!"
    }
}
